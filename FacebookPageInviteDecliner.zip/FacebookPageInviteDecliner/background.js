chrome.action.onClicked.addListener((tab) => {
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: async function () {
      const delay = (ms) => new Promise(res => setTimeout(res, ms));

      const inviteEllipses = Array.from(document.querySelectorAll('div[aria-label="Actions for this invite"], div[aria-label="More options"], div[aria-label="More"]'))
        .filter(el => el.getAttribute('role') === 'button');

      if (inviteEllipses.length === 0) {
        alert("❌ Couldn't find any ellipsis buttons inside the invites list.");
        return;
      }

      for (let i = 0; i < inviteEllipses.length; i++) {
        const btn = inviteEllipses[i];
        btn.scrollIntoView({ behavior: 'smooth', block: 'center' });
        btn.click();
        console.log(`🔘 Opened menu for invite #${i + 1}`);
        await delay(800);

        const declineOption = Array.from(document.querySelectorAll('div[role="menuitem"] span'))
          .find(span => span.textContent.trim().toLowerCase() === 'decline');

        if (declineOption) {
          const clickable = declineOption.closest('div[role="menuitem"]');
          if (clickable) {
            clickable.click();
            console.log(`❌ Clicked Decline for invite #${i + 1}`);
            await delay(1000);

            // Now click the Confirm button on the modal
            const confirmButton = Array.from(document.querySelectorAll('div[role="dialog"] div[role="button"], div[role="dialog"] button'))
              .find(el => el.textContent.trim().toLowerCase() === 'confirm');

            if (confirmButton) {
              confirmButton.click();
              console.log(`✅ Confirmed Decline #${i + 1}`);
            } else {
              console.warn(`⚠️ Confirm button not found for invite #${i + 1}`);
            }
          } else {
            console.warn(`⚠️ Couldn't find clickable menuitem for Decline #${i + 1}`);
          }
        } else {
          console.warn(`⚠️ No "Decline" found after opening menu #${i + 1}`);
        }

        await delay(2000 + Math.random() * 1000); // mimic human behavior
      }

      alert("🏁 All invites processed and confirmed.");
    }
  });
});
